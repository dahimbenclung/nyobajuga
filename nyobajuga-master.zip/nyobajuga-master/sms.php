echo "# nyobajuga" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/dahimbenclung/nyobajuga.git
git push -u origin master
